package com.just.print.ui.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.just.print.R;
import com.just.print.app.AppData;
import com.just.print.app.BaseFragment;
import com.just.print.db.dao.SaleRecordDao;
import com.just.print.util.DbUtil;
import com.stupid.method.reflect.StupidReflect;
import com.stupid.method.reflect.annotation.XClick;
import com.stupid.method.reflect.annotation.XViewByID;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;

public class SynchronizeDBFragment extends BaseFragment{

    private HashMap<String,List<String>> contentForPrintMap;

    @XViewByID(R.id.store_name)
    EditText store_name;
    @XViewByID(R.id.license)
    EditText license;
    @XViewByID(R.id.lastModified)
    TextView lastModified;

    private SaleRecordDao saleRecordDao;
    private long now;

    @Override
    protected int getLayoutId() {
        return R.layout.synchronize_db_fragment;
    }

    @SuppressLint("NewApi")
    @Override
    public void onCreated(Bundle savedInstanceState) {
        new StupidReflect(this, getView()).init();
        store_name.setText(AppData.getShopName());
        license.setText(AppData.getLicense());
        String lastSyncDate = AppData.getLastModifyTime();
        if(lastSyncDate == null || lastSyncDate.length() == 0){
            lastSyncDate = "1";
        }
        lastModified.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(lastSyncDate)));
    }

    @XClick({R.id.btnConfirmResetReportOK})
    private void onButtonOK(){
        String code = license.getText().toString();
        if(code.length() < 6){
            showToast("Please activate the application first.");
            return;
        }
        DbUtil.syncDbOntoServer(code, store_name.getText().toString(),  false);
        getActivity().finish();
    }

    @XClick({R.id.buttonCancel})
    private void onButtonCancel(){
        getActivity().finish();
    }

}
